lexnlp.nlp.en.segments package
==============================

Submodules
----------

lexnlp.nlp.en.segments.heading\_heuristics module
-------------------------------------------------

.. automodule:: lexnlp.nlp.en.segments.heading_heuristics
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.segments.pages module
-----------------------------------

.. automodule:: lexnlp.nlp.en.segments.pages
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.segments.paragraphs module
----------------------------------------

.. automodule:: lexnlp.nlp.en.segments.paragraphs
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.segments.sections module
--------------------------------------

.. automodule:: lexnlp.nlp.en.segments.sections
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.segments.sentences module
---------------------------------------

.. automodule:: lexnlp.nlp.en.segments.sentences
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.segments.titles module
------------------------------------

.. automodule:: lexnlp.nlp.en.segments.titles
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.segments.utils module
-----------------------------------

.. automodule:: lexnlp.nlp.en.segments.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.nlp.en.segments
   :members:
   :undoc-members:
   :show-inheritance:
