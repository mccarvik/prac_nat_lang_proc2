lexnlp.extract.all\_locales.tests package
=========================================

Submodules
----------

lexnlp.extract.all\_locales.tests.test\_locales module
------------------------------------------------------

.. automodule:: lexnlp.extract.all_locales.tests.test_locales
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.extract.all_locales.tests
   :members:
   :undoc-members:
   :show-inheritance:
