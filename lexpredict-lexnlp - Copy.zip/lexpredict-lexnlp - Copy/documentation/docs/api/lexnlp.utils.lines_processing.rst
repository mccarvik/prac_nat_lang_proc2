lexnlp.utils.lines\_processing package
======================================

Submodules
----------

lexnlp.utils.lines\_processing.line\_processor module
-----------------------------------------------------

.. automodule:: lexnlp.utils.lines_processing.line_processor
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.utils.lines\_processing.parsed\_text\_corrector module
-------------------------------------------------------------

.. automodule:: lexnlp.utils.lines_processing.parsed_text_corrector
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.utils.lines\_processing.parsed\_text\_quality\_estimator module
----------------------------------------------------------------------

.. automodule:: lexnlp.utils.lines_processing.parsed_text_quality_estimator
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.utils.lines\_processing.phrase\_finder module
----------------------------------------------------

.. automodule:: lexnlp.utils.lines_processing.phrase_finder
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.utils.lines_processing
   :members:
   :undoc-members:
   :show-inheritance:
