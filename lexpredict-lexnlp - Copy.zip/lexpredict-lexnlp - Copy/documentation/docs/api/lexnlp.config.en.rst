lexnlp.config.en package
========================

Submodules
----------

lexnlp.config.en.company\_types module
--------------------------------------

.. automodule:: lexnlp.config.en.company_types
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.config.en.geoentities\_config module
-------------------------------------------

.. automodule:: lexnlp.config.en.geoentities_config
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.config.en
   :members:
   :undoc-members:
   :show-inheritance:
