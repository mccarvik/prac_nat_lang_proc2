lexnlp.extract.common.entities package
======================================

Submodules
----------

lexnlp.extract.common.entities.entity\_banlist module
-----------------------------------------------------

.. automodule:: lexnlp.extract.common.entities.entity_banlist
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.extract.common.entities
   :members:
   :undoc-members:
   :show-inheritance:
