lexnlp.nlp.train.en package
===========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   lexnlp.nlp.train.en.tests

Submodules
----------

lexnlp.nlp.train.en.train\_section\_segmanizer module
-----------------------------------------------------

.. automodule:: lexnlp.nlp.train.en.train_section_segmanizer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.nlp.train.en
   :members:
   :undoc-members:
   :show-inheritance:
