lexnlp.tests package
====================

Submodules
----------

lexnlp.tests.dictionary\_comparer module
----------------------------------------

.. automodule:: lexnlp.tests.dictionary_comparer
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.tests.lexnlp\_tests module
---------------------------------

.. automodule:: lexnlp.tests.lexnlp_tests
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.tests.typed\_annotations\_tests module
---------------------------------------------

.. automodule:: lexnlp.tests.typed_annotations_tests
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.tests.upload\_benchmarks module
--------------------------------------

.. automodule:: lexnlp.tests.upload_benchmarks
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.tests.utility\_for\_testing module
-----------------------------------------

.. automodule:: lexnlp.tests.utility_for_testing
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.tests.values\_comparer module
------------------------------------

.. automodule:: lexnlp.tests.values_comparer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.tests
   :members:
   :undoc-members:
   :show-inheritance:
