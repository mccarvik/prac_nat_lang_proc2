lexnlp.extract.en.addresses.tests package
=========================================

Submodules
----------

lexnlp.extract.en.addresses.tests.test\_addresses module
--------------------------------------------------------

.. automodule:: lexnlp.extract.en.addresses.tests.test_addresses
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.extract.en.addresses.tests
   :members:
   :undoc-members:
   :show-inheritance:
