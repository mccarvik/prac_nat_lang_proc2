lexnlp.extract.common.copyrights package
========================================

Submodules
----------

lexnlp.extract.common.copyrights.copyright\_en\_style\_parser module
--------------------------------------------------------------------

.. automodule:: lexnlp.extract.common.copyrights.copyright_en_style_parser
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.copyrights.copyright\_parser module
---------------------------------------------------------

.. automodule:: lexnlp.extract.common.copyrights.copyright_parser
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.copyrights.copyright\_parsing\_methods module
-------------------------------------------------------------------

.. automodule:: lexnlp.extract.common.copyrights.copyright_parsing_methods
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.copyrights.copyright\_pattern\_found module
-----------------------------------------------------------------

.. automodule:: lexnlp.extract.common.copyrights.copyright_pattern_found
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.extract.common.copyrights
   :members:
   :undoc-members:
   :show-inheritance:
