LexNLP package
==============


.. image:: https://s3.amazonaws.com/lexpredict.com-marketing/graphics/lexpredict_lexnlp_logo_horizontal_1.png
   :width: 200px
   :alt: LexNLP
   :align: left


.. toctree::
    :maxdepth: 4
    :caption: Contents:

    modules/extract/extract
    modules/nlp/nlp

