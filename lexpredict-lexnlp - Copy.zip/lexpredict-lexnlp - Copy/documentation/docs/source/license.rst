.. _license:

============
License
============

AGPL License
----------------
LexNLP is available by default under the terms of the GNU Affero General Public License v3.0.
https://github.com/LexPredict/lexpredict-lexnlp/blob/2.3.0/LICENSE


License Release
----------------
If you would like to request a release from the terms of the default AGPLv3 license, please contact us at:
ContraxSuite Licensing <license@contraxsuite.com>.

