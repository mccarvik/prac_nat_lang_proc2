get_character_distribution
==========================

.. currentmodule:: lexnlp.nlp.en.transforms.characters

.. autofunction:: get_character_distribution
