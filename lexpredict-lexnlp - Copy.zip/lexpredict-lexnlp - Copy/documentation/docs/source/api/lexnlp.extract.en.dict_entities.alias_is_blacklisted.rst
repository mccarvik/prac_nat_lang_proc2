alias_is_blacklisted
====================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: alias_is_blacklisted
