build_sentence_model
====================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autofunction:: build_sentence_model
