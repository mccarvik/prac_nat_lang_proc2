COLLOCATION_SIZE
================

.. currentmodule:: lexnlp.nlp.en.tokens

.. autodata:: COLLOCATION_SIZE
