get_urls
========

.. currentmodule:: lexnlp.extract.en.urls

.. autofunction:: get_urls
