entity_config
=============

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: entity_config
