RE_NEW_LINE
===========

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autodata:: RE_NEW_LINE
