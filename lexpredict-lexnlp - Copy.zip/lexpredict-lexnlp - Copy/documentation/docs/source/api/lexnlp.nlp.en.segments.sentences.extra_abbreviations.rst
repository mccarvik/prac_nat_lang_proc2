extra_abbreviations
===================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: extra_abbreviations
