MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autodata:: MODULE_PATH
