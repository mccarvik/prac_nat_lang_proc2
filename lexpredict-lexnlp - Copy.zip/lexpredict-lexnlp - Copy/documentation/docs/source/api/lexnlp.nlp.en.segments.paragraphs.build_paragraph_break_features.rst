build_paragraph_break_features
==============================

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autofunction:: build_paragraph_break_features
