get_ratios
==========

.. currentmodule:: lexnlp.extract.en.ratios

.. autofunction:: get_ratios
