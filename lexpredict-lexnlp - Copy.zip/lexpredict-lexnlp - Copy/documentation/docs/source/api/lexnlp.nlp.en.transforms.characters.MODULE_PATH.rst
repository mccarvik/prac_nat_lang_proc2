MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.transforms.characters

.. autodata:: MODULE_PATH
