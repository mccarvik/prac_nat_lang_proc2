build_date_model
================

.. currentmodule:: lexnlp.extract.en.dates

.. autofunction:: build_date_model
