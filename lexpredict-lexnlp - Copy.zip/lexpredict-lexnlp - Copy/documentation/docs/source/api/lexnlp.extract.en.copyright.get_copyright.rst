get_copyright
=============

.. currentmodule:: lexnlp.extract.en.copyright

.. autofunction:: get_copyright
