build_document_line_distribution
================================

.. currentmodule:: lexnlp.nlp.en.segments.utils

.. autofunction:: build_document_line_distribution
