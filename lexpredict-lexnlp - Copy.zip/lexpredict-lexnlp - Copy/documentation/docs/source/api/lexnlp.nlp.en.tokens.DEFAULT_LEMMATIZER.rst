DEFAULT_LEMMATIZER
==================

.. currentmodule:: lexnlp.nlp.en.tokens

.. autodata:: DEFAULT_LEMMATIZER
