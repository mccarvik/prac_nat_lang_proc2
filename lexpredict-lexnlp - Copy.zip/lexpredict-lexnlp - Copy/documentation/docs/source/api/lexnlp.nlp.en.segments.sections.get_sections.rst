get_sections
============

.. currentmodule:: lexnlp.nlp.en.segments.sections

.. autofunction:: get_sections
