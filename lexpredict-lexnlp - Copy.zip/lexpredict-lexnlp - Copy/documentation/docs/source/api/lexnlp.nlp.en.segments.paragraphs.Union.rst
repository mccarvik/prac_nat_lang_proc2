Union
=====

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autodata:: Union
