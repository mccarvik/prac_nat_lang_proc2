lexnlp.extract.en.addresses package
===================================

Subpackages
-----------

.. toctree::

   lexnlp.extract.en.addresses.tests

Submodules
----------

lexnlp.extract.en.addresses.address\_features module
----------------------------------------------------

.. automodule:: lexnlp.extract.en.addresses.address_features
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.addresses.addresses module
--------------------------------------------

.. automodule:: lexnlp.extract.en.addresses.addresses
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.en.addresses
   :members:
   :undoc-members:
   :show-inheritance:
