get_titles
==========

.. currentmodule:: lexnlp.nlp.en.segments.titles

.. autofunction:: get_titles
