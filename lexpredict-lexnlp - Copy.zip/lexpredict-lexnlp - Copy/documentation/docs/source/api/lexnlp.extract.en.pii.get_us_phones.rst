get_us_phones
=============

.. currentmodule:: lexnlp.extract.en.pii

.. autofunction:: get_us_phones
