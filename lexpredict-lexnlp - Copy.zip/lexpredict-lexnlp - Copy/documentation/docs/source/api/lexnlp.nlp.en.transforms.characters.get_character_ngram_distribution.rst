get_character_ngram_distribution
================================

.. currentmodule:: lexnlp.nlp.en.transforms.characters

.. autofunction:: get_character_ngram_distribution
