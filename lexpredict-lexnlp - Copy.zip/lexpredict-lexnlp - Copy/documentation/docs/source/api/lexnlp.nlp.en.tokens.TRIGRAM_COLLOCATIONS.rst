TRIGRAM_COLLOCATIONS
====================

.. currentmodule:: lexnlp.nlp.en.tokens

.. autodata:: TRIGRAM_COLLOCATIONS
