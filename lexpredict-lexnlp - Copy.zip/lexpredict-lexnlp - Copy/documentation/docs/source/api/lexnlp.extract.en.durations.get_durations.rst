get_durations
=============

.. currentmodule:: lexnlp.extract.en.durations

.. autofunction:: get_durations
