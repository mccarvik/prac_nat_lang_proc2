get_adverbs
===========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_adverbs
