MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.segments.titles

.. autodata:: MODULE_PATH
