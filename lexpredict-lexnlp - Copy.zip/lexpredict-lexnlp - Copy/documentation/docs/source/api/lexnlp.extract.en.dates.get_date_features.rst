get_date_features
=================

.. currentmodule:: lexnlp.extract.en.dates

.. autofunction:: get_date_features
