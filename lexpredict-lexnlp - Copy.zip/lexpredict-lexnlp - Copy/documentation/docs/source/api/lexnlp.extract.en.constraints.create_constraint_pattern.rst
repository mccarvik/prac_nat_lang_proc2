create_constraint_pattern
=========================

.. currentmodule:: lexnlp.extract.en.constraints

.. autofunction:: create_constraint_pattern
