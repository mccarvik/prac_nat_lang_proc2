lexnlp.nlp.en.tests package
===========================

Submodules
----------

lexnlp.nlp.en.tests.test\_pages module
--------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_pages
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_paragraphs module
-------------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_paragraphs
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_sections module
-----------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_sections
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_sentences module
------------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_sentences
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_stanford module
-----------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_stanford
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_stanford\_missing module
--------------------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_stanford_missing
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_titles module
---------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_titles
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_tokens module
---------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_tokens
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tests.test\_transforms module
-------------------------------------------

.. automodule:: lexnlp.nlp.en.tests.test_transforms
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.nlp.en.tests
   :members:
   :undoc-members:
   :show-inheritance:
