get_paragraphs
==============

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autofunction:: get_paragraphs
