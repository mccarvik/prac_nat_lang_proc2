get_distances
=============

.. currentmodule:: lexnlp.extract.en.distances

.. autofunction:: get_distances
