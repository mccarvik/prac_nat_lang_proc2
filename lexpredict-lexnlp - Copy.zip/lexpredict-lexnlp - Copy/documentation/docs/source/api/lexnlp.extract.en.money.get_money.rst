get_money
=========

.. currentmodule:: lexnlp.extract.en.money

.. autofunction:: get_money
