lexnlp.utils.unicode package
============================

Subpackages
-----------

.. toctree::

   lexnlp.utils.unicode.tests

Submodules
----------

lexnlp.utils.unicode.unicode\_lookup module
-------------------------------------------

.. automodule:: lexnlp.utils.unicode.unicode_lookup
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.utils.unicode
   :members:
   :undoc-members:
   :show-inheritance:
