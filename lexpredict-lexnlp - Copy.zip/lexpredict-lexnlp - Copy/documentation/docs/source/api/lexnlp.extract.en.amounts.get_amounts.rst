get_amounts
===========

.. currentmodule:: lexnlp.extract.en.amounts

.. autofunction:: get_amounts
