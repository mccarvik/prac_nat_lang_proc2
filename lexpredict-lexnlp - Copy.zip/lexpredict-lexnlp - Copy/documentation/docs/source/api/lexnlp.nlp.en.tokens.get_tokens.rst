get_tokens
==========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_tokens
