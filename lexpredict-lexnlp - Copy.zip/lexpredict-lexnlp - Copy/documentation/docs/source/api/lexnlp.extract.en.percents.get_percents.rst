get_percents
============

.. currentmodule:: lexnlp.extract.en.percents

.. autofunction:: get_percents
