get_entity_name
===============

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: get_entity_name
