lexnlp package
==============

Subpackages
-----------

.. toctree::

   lexnlp.config
   lexnlp.extract
   lexnlp.nlp
   lexnlp.tests
   lexnlp.utils

Module contents
---------------

.. automodule:: lexnlp
   :members:
   :undoc-members:
   :show-inheritance:
