SENTENCE_SPLITTERS
==================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: SENTENCE_SPLITTERS
