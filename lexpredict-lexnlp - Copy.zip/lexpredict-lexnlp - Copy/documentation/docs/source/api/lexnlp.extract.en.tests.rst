lexnlp.extract.en.tests package
===============================

Submodules
----------

lexnlp.extract.en.tests.test\_acts module
-----------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_acts
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_amounts module
--------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_amounts
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_amounts\_plain module
---------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_amounts_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_citations module
----------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_citations
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_citations\_plain module
-----------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_citations_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_conditions module
-----------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_conditions
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_conditions\_plain module
------------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_conditions_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_constraints module
------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_constraints
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_constraints\_plain module
-------------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_constraints_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_copyright module
----------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_copyright
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_copyright\_plain module
-----------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_copyright_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_courts module
-------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_courts
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_cusip module
------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_cusip
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_dates module
------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_dates
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_dates\_plain module
-------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_dates_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_definitions module
------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_definitions
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_definitions\_template module
----------------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_definitions_template
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_dict\_entities module
---------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_dict_entities
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_distance module
---------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_distance
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_distances\_plain module
-----------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_distances_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_durations module
----------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_durations
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_durations\_plain module
-----------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_durations_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_geoentities module
------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_geoentities
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_geoentities\_plain module
-------------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_geoentities_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_introductory\_words\_detector module
------------------------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_introductory_words_detector
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_money module
------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_money
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_money\_plain module
-------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_money_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_parsing\_speed module
---------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_parsing_speed
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_percent\_plain module
---------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_percent_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_percents module
---------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_percents
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_phone\_plain module
-------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_phone_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_pii module
----------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_pii
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_ratios module
-------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_ratios
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_ratios\_plain module
--------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_ratios_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_regulations module
------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_regulations
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_regulations\_plain module
-------------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_regulations_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_span\_tokenizer module
----------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_span_tokenizer
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_ssn\_plain module
-----------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_ssn_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_trademarks module
-----------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_trademarks
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_trademarks\_plain module
------------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_trademarks_plain
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_urls module
-----------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_urls
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.tests.test\_urls\_plain module
------------------------------------------------

.. automodule:: lexnlp.extract.en.tests.test_urls_plain
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.en.tests
   :members:
   :undoc-members:
   :show-inheritance:
