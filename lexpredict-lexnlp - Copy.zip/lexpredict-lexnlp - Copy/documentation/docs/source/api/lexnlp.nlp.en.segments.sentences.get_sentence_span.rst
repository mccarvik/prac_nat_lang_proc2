get_sentence_span
=================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autofunction:: get_sentence_span
