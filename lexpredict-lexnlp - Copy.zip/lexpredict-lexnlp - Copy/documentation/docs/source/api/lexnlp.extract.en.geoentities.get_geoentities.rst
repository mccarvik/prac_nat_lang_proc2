get_geoentities
===============

.. currentmodule:: lexnlp.extract.en.geoentities

.. autofunction:: get_geoentities
