Union
=====

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: Union
