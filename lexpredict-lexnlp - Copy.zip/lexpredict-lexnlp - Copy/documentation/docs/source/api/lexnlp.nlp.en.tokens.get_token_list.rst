get_token_list
==============

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_token_list
