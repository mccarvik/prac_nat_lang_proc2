lexnlp.extract.de.tests package
===============================

Submodules
----------

lexnlp.extract.de.tests.test\_amounts module
--------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_amounts
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_citations module
----------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_citations
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_copyrights module
-----------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_copyrights
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_court\_citations module
-----------------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_court_citations
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_courts module
-------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_courts
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_dates module
------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_dates
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_definitions module
------------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_definitions
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_durations module
----------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_durations
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_geoentities module
------------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_geoentities
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_laws module
-----------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_laws
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.de.tests.test\_percents module
---------------------------------------------

.. automodule:: lexnlp.extract.de.tests.test_percents
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.de.tests
   :members:
   :undoc-members:
   :show-inheritance:
