get_conditions
==============

.. currentmodule:: lexnlp.extract.en.conditions

.. autofunction:: get_conditions
