lexnlp.extract.common.annotations package
=========================================

Submodules
----------

lexnlp.extract.common.annotations.act\_annotation module
--------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.act_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.amount\_annotation module
-----------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.amount_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.citation\_annotation module
-------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.citation_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.company\_annotation module
------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.company_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.condition\_annotation module
--------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.condition_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.constraint\_annotation module
---------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.constraint_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.copyright\_annotation module
--------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.copyright_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.court\_annotation module
----------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.court_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.court\_citation\_annotation module
--------------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.court_citation_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.cusip\_annotation module
----------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.cusip_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.date\_annotation module
---------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.date_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.definition\_annotation module
---------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.definition_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.distance\_annotation module
-------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.distance_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.duration\_annotation module
-------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.duration_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.geo\_annotation module
--------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.geo_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.law\_annotation module
--------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.law_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.money\_annotation module
----------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.money_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.percent\_annotation module
------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.percent_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.phone\_annotation module
----------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.phone_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.phrase\_position\_finder module
-----------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.phrase_position_finder
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.ratio\_annotation module
----------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.ratio_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.regulation\_annotation module
---------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.regulation_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.ssn\_annotation module
--------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.ssn_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.text\_annotation module
---------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.text_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.trademark\_annotation module
--------------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.trademark_annotation
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.annotations.url\_annotation module
--------------------------------------------------------

.. automodule:: lexnlp.extract.common.annotations.url_annotation
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.common.annotations
   :members:
   :undoc-members:
   :show-inheritance:
