get_ngram_distribution
======================

.. currentmodule:: lexnlp.nlp.en.transforms.tokens

.. autofunction:: get_ngram_distribution
