get_np
======

.. currentmodule:: lexnlp.extract.en.amounts

.. autofunction:: get_np
