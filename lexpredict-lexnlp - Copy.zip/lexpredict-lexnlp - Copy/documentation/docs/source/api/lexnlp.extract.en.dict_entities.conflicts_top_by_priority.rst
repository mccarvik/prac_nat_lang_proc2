conflicts_top_by_priority
=========================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: conflicts_top_by_priority
