PAGE_SEGMENTER_MODEL
====================

.. currentmodule:: lexnlp.nlp.en.segments.pages

.. autodata:: PAGE_SEGMENTER_MODEL
