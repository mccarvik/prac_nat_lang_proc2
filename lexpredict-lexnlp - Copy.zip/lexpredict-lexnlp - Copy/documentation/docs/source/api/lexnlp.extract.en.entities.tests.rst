lexnlp.extract.en.entities.tests package
========================================

Submodules
----------

lexnlp.extract.en.entities.tests.test\_get\_companies module
------------------------------------------------------------

.. automodule:: lexnlp.extract.en.entities.tests.test_get_companies
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.entities.tests.test\_nltk\_maxent module
----------------------------------------------------------

.. automodule:: lexnlp.extract.en.entities.tests.test_nltk_maxent
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.entities.tests.test\_nltk\_re module
------------------------------------------------------

.. automodule:: lexnlp.extract.en.entities.tests.test_nltk_re
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.entities.tests.test\_stanford\_ner module
-----------------------------------------------------------

.. automodule:: lexnlp.extract.en.entities.tests.test_stanford_ner
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.en.entities.tests
   :members:
   :undoc-members:
   :show-inheritance:
