PARAGRAPH_SEGMENTER_MODEL
=========================

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autodata:: PARAGRAPH_SEGMENTER_MODEL
