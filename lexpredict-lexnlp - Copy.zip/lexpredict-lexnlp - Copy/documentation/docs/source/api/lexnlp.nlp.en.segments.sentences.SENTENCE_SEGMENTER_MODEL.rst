SENTENCE_SEGMENTER_MODEL
========================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: SENTENCE_SEGMENTER_MODEL
