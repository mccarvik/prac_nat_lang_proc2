get_entity_aliases
==================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: get_entity_aliases
