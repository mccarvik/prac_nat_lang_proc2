text2num
========

.. currentmodule:: lexnlp.extract.en.amounts

.. autofunction:: text2num
