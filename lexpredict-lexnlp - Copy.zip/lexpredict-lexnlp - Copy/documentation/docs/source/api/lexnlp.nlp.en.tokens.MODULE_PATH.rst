MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autodata:: MODULE_PATH
