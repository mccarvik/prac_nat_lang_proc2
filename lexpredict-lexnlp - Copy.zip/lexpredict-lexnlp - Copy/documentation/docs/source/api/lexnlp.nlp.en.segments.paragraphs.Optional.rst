Optional
========

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autodata:: Optional
