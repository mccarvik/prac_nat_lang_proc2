UNICODE_CHAR_TOP_CATEGORY_MAPPING
=================================

.. currentmodule:: lexnlp.nlp.en.segments.titles

.. autodata:: UNICODE_CHAR_TOP_CATEGORY_MAPPING
