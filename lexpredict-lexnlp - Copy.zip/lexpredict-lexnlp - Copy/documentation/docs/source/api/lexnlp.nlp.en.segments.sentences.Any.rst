Any
===

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: Any
