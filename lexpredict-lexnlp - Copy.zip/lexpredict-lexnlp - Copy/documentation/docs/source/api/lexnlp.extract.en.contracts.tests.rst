lexnlp.extract.en.contracts.tests package
=========================================

Submodules
----------

lexnlp.extract.en.contracts.tests.test\_contracts module
--------------------------------------------------------

.. automodule:: lexnlp.extract.en.contracts.tests.test_contracts
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.en.contracts.tests
   :members:
   :undoc-members:
   :show-inheritance:
