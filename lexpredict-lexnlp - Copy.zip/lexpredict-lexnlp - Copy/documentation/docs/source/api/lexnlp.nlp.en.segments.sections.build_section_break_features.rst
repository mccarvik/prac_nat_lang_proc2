build_section_break_features
============================

.. currentmodule:: lexnlp.nlp.en.segments.sections

.. autofunction:: build_section_break_features
