get_verbs
=========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_verbs
