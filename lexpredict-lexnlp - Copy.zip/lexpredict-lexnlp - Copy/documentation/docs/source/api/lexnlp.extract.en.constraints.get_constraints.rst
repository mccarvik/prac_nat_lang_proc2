get_constraints
===============

.. currentmodule:: lexnlp.extract.en.constraints

.. autofunction:: get_constraints
