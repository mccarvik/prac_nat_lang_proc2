create_condition_pattern
========================

.. currentmodule:: lexnlp.extract.en.conditions

.. autofunction:: create_condition_pattern
