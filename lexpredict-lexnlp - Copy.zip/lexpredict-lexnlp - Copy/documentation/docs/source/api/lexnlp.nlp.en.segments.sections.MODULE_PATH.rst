MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.segments.sections

.. autodata:: MODULE_PATH
