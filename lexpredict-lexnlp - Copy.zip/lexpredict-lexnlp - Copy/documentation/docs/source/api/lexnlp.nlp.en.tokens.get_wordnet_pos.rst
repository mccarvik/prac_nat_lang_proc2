get_wordnet_pos
===============

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_wordnet_pos
