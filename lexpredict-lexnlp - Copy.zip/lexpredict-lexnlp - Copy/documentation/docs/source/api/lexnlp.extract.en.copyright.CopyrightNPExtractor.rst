CopyrightNPExtractor
====================

.. currentmodule:: lexnlp.extract.en.copyright

.. autoclass:: CopyrightNPExtractor
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~CopyrightNPExtractor.allowed_pos
      ~CopyrightNPExtractor.allowed_sym

   .. rubric:: Methods Summary

   .. autosummary::

      ~CopyrightNPExtractor.strip_np

   .. rubric:: Attributes Documentation

   .. autoattribute:: allowed_pos
   .. autoattribute:: allowed_sym

   .. rubric:: Methods Documentation

   .. automethod:: strip_np
